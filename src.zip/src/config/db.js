// const knex = require("knex");
const { Sequelize } = require("sequelize");
// const { Model } = require("objection");

const sequelize = new Sequelize("hackerkernel_task", "root", "", {
  host: "localhost",
  dialect: "mysql",
});
console.log(sequelize, "data sequelize -----");
sequelize
  .authenticate()
  .then(() => console.log("musql connected with sequelize--"))
  .catch((err) => console.log("error with connection", err));

module.exports = sequelize;

// const connectDb = knex({
//   client: "mysql2",
//   connection: {
//     host: "localhost",
//     user: "root",
//     password: "",
//     database: "hackerkernel_task",
//   },
// });

// Model.knex(connectDb);

// module.exports = connectDb;
