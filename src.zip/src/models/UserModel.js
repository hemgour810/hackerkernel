// const { Model } = require("objection");
const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const Joi = require("joi");

// const TaskModel = require("./TaskModel");
// const { join, from } = require("../../db");

const UserModel = sequelize.define("User", {
  name: DataTypes.STRING,
  email: DataTypes.STRING,
  contact: DataTypes.NUMBER,
});

UserModel.validateUser = (data) => {
  const Schema = Joi.object({
    name: Joi.string().min(3).max(100).required(),
    email: Joi.string()
      .email({ tlds: { allow: false } })
      .required(),
  });
  return Schema.validate(data);
};
// class UserModel extends Model {
//   static get tableName() {
//     return "users";
//   }

//   static get relationMappings() {
//     return {
//       tasks: {
//         relation: Model.HasManyRelation,
//         modelClass: Task,
//         join: {
//           from: "users.id",
//           to: "tasks.user_id",
//         },
//       },
//     };
//   }
// }

module.exports = UserModel;
